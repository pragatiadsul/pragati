package com.Expense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableWebSecurity
public class ExpenseTracker1Application {

	public static void main(String[] args) {
		SpringApplication.run(ExpenseTracker1Application.class, args);
//		SpringApplication.run(EmailappApplication.class, args);
	}

}
