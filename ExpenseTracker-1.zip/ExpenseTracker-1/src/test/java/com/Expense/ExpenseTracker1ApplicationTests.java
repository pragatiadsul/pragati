package com.Expense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTracker1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
