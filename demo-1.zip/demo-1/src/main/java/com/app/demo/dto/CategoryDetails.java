package com.app.demo.dto;

public class CategoryDetails {

}
